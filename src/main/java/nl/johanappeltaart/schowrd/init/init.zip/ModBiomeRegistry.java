package com.johanappeltaart.schowrd.init;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.registry.WorldGenRegistries;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeMaker;
import net.minecraft.world.biome.Biomes;

public class ModBiomeRegistry {
    private static final Int2ObjectMap<RegistryKey<Biome>> BY_RAW_ID = new Int2ObjectArrayMap<>();
    public static final Biome PLAINS = register(1, Biomes.PLAINS, BiomeMaker.createPlains(false));
    public static final Biome THE_VOID = register(127, Biomes.THE_VOID, BiomeMaker.createTheVoid());

    private static Biome register(int p_244204_0_, RegistryKey<Biome> p_244204_1_, Biome p_244204_2_) {
        BY_RAW_ID.put(p_244204_0_, p_244204_1_);
        return WorldGenRegistries.set(WorldGenRegistries.BIOME, p_244204_0_, p_244204_1_, p_244204_2_);
    }

    static{
         register(0,ModBiomes.BANANA_PLAINS, ModBiomeMaker.createBananaPlains(false));
    }
}
