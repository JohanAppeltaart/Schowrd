package com.johanappeltaart.schowrd.init;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.block.BlockState;
import net.minecraft.world.gen.surfacebuilders.ISurfaceBuilderConfig;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilderConfig;

public class ModSurfaceBuilderConfig implements ISurfaceBuilderConfig {
//    public static final Codec<SurfaceBuilderConfig> CODEC = RecordCodecBuilder.create((p_237204_0_) -> {
//        return p_237204_0_.group(BlockState.CODEC.fieldOf("top_material").forGetter((p_237207_0_) -> {
//            return p_237207_0_.topMaterial;
//        }), BlockState.CODEC.fieldOf("under_material").forGetter((p_237206_0_) -> {
//            return p_237206_0_.underMaterial;
//        }), BlockState.CODEC.fieldOf("underwater_material").forGetter((p_237205_0_) -> {
//            return p_237205_0_.underWaterMaterial;
//        })).apply(p_237204_0_, SurfaceBuilderConfig::new);
//    });
    private final BlockState topMaterial;
    private final BlockState underMaterial;
    private final BlockState underWaterMaterial;

    public ModSurfaceBuilderConfig(BlockState p_i48954_1_, BlockState p_i48954_2_, BlockState p_i48954_3_) {
        this.topMaterial = p_i48954_1_;
        this.underMaterial = p_i48954_2_;
        this.underWaterMaterial = p_i48954_3_;
    }

    public BlockState getTop() {
        return this.topMaterial;
    }

    public BlockState getUnder() {
        return this.underMaterial;
    }

    public BlockState getUnderWaterMaterial() {
        return this.underWaterMaterial;
    }
}
