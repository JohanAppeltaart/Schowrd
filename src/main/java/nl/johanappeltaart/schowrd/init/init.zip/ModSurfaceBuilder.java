package com.johanappeltaart.schowrd.init;

import com.mojang.serialization.Codec;
import net.minecraft.block.BlockState;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunk;
import net.minecraft.world.gen.surfacebuilders.*;

import java.util.Random;

public abstract class ModSurfaceBuilder <C extends ISurfaceBuilderConfig> extends net.minecraftforge.registries.ForgeRegistryEntry<SurfaceBuilder<?>>{
    public static final ModSurfaceBuilderConfig GRASS_DIRT_BANANA_BLOCK_CONFIG = new ModSurfaceBuilderConfig(ModBlocks.BANANA_GRASS_BLOCK.get().getDefaultState(),ModBlocks.BANANA_DIRT.get().getDefaultState(), ModBlocks.BANANA_BLOCK.get().getDefaultState());
    public static final SurfaceBuilder<SurfaceBuilderConfig> DEFAULT = register("default", new DefaultSurfaceBuilder(SurfaceBuilderConfig.CODEC));
//    public static final ModSurfaceBuilder<ModSurfaceBuilderConfig> NOPE = register("nope", new NoopSurfaceBuilder(SurfaceBuilderConfig.CODEC));
//
    private final Codec<ModConfiguredSurfaceBuilder<C>> field_25016;
    private static <C extends ISurfaceBuilderConfig, F extends SurfaceBuilder<C>> F register(String p_215389_0_, F p_215389_1_) {
        return Registry.register(Registry.SURFACE_BUILDER, p_215389_0_, p_215389_1_);
    }

    public ModSurfaceBuilder(Codec<C> p_i232136_1_) {
        this.field_25016 = p_i232136_1_.fieldOf("config").xmap(this::method_30478, ModConfiguredSurfaceBuilder::getConfig).codec();
    }

    public Codec<ModConfiguredSurfaceBuilder<C>> method_29003() {
        return this.field_25016;
    }

    public ModConfiguredSurfaceBuilder<C> method_30478(C p_242929_1_) {
        return new ModConfiguredSurfaceBuilder<>(this, p_242929_1_);
    }

    public abstract void buildSurface(Random p_205610_1_, IChunk p_205610_2_, Biome p_205610_3_, int p_205610_4_, int p_205610_5_, int p_205610_6_, double p_205610_7_, BlockState p_205610_9_, BlockState p_205610_10_, int p_205610_11_, long p_205610_12_, C p_205610_14_);

    public void setSeed(long p_205548_1_) {
    }
}
