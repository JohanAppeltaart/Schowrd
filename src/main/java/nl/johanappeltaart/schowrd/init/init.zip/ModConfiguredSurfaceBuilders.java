package com.johanappeltaart.schowrd.init;

import net.minecraft.util.registry.WorldGenRegistries;
import net.minecraft.world.gen.surfacebuilders.ConfiguredSurfaceBuilder;
import net.minecraft.world.gen.surfacebuilders.ISurfaceBuilderConfig;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilder;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilderConfig;

public class ModConfiguredSurfaceBuilders {
    public static final ConfiguredSurfaceBuilder<SurfaceBuilderConfig> BANANA_GRASS = register("banana_grass", ModSurfaceBuilder.DEFAULT.method_30478(ModSurfaceBuilder.GRASS_DIRT_BANANA_BLOCK_CONFIG));

    private static <SC extends ISurfaceBuilderConfig> ModConfiguredSurfaceBuilder<SC> register(String p_244192_0_, ModConfiguredSurfaceBuilder<SC> p_244192_1_) {
        return WorldGenRegistries.add(WorldGenRegistries.CONFIGURED_SURFACE_BUILDER, p_244192_0_, p_244192_1_);
    }


}
